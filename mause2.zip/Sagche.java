/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sagche;
import java.util.scanner
/**
 *
 * @author estudiante
 */
public class Sagche {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       int M=10;
      
       int c=10;
       
       int R=M+C% 2;
       
       System.out,println("la suma  de M + " +"la  suma de c"+ "dividido entre 2"+ "es igual a:"+ R);
        // TODO code application logic here
    }
    
}
